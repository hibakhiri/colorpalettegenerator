document.addEventListener("DOMContentLoaded", function() {
    const imageInput = document.getElementById('imageInput');
    const colorCount = document.getElementById('colorCount');
    const uploadedImage = document.getElementById('uploadedImage');
    const paletteDiv = document.getElementById('palette');

    imageInput.addEventListener('change', handleImageUpload);

    function handleImageUpload() {
        const file = imageInput.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(event) {
                uploadedImage.src = event.target.result;
                // Optionally, clear the palette when a new image is uploaded
                paletteDiv.innerHTML = '';
            }
            reader.readAsDataURL(file);
        }
    }

    window.generatePalette = function() {
        // Here you can implement the logic to generate the color palette
        // For now, this is just a placeholder
        const colors = Array.from({length: colorCount.value}, (_, i) => {
            return `#${Math.floor(Math.random() * 16777215).toString(16)}`;
        });
        displayPalette(colors);
    };

    function displayPalette(colors) {
        paletteDiv.innerHTML = ''; // Clear previous palette
        colors.forEach(color => {
            const colorBox = document.createElement('div');
            colorBox.className = 'color-box';
            colorBox.style.backgroundColor = color;
            colorBox.textContent = color;
            paletteDiv.appendChild(colorBox);
        });
    }
});